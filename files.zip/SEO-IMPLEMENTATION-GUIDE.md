# AllPDFStuff — SEO Implementation Guide
## What's included & how to add everything to your site

---

## FILES DELIVERED

| File | URL slug | Status |
|------|----------|--------|
| compress-pdf.html | /compress-pdf | ✅ Ready |
| merge-pdf.html | /merge-pdf | ✅ Ready |
| split-pdf.html | /split-pdf | ✅ Ready |
| pdf-to-word.html | /pdf-to-word | ✅ Ready |
| word-to-pdf.html | /word-to-pdf | ✅ Ready |

---

## STEP 1 — Add the 5 tool pages to your site

Upload each file to your hosting exactly matching the filename.

For example:
- `compress-pdf.html` → accessible at `www.allpdfstuff.com/compress-pdf`

If your hosting requires `.html` extensions, they'll work as-is.
If your server strips `.html` (clean URLs), rename them to folders with `index.html` inside:
- `/compress-pdf/index.html`
- `/merge-pdf/index.html`
- etc.

**Each page already includes:**
- Keyword-optimised H1, meta title, meta description
- 500–700 words of structured SEO content
- How-it-works steps section
- Features grid
- Use-cases section
- Expandable FAQ (with accordion JS)
- FAQ schema markup (for Google rich results)
- WebApplication schema markup
- Internal links to all other tool pages
- Matching visual style to your existing site

---

## STEP 2 — Add schema markup to your HOMEPAGE

Paste this into the `<head>` section of your main `index.html`:

```html
<!-- Website Schema -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "AllPDFStuff",
  "url": "https://www.allpdfstuff.com",
  "description": "Free online PDF tools to compress, merge, split and convert PDF files. Fast, secure, browser-based.",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://www.allpdfstuff.com/?s={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>

<!-- Organization Schema -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "AllPDFStuff",
  "url": "https://www.allpdfstuff.com",
  "logo": "https://www.allpdfstuff.com/logo.png",
  "sameAs": []
}
</script>
```

---

## STEP 3 — Update your homepage H1 and meta

Replace your current homepage meta with these:

```html
<title>Free PDF Tools – Compress, Merge, Convert & Edit PDFs Online | AllPDFStuff</title>
<meta name="description" content="15 free online PDF tools in one place. Compress, merge, split, convert and edit PDF files in your browser. No software, no signup, files deleted in 1 hour.">
```

Replace your current H1 heading with:
```
Free PDF Tools – Compress, Merge & Convert PDFs Online
```

---

## STEP 4 — Update footer links to point to new pages

In your existing `index.html` footer, the Tools links currently point to `#upload`.
Update them to point to the new pages:

```html
<!-- REPLACE THIS: -->
<a href="#upload">Compress PDF</a>
<a href="#upload">Merge PDF</a>
<a href="#upload">Split PDF</a>

<!-- WITH THIS: -->
<a href="/compress-pdf">Compress PDF</a>
<a href="/merge-pdf">Merge PDF</a>
<a href="/split-pdf">Split PDF</a>
<a href="/pdf-to-word">PDF to Word</a>
<a href="/word-to-pdf">Word to PDF</a>
```

---

## STEP 5 — Update tool cards on homepage to link to new pages

In the "Everything PDF, in one place" tool grid section, update each tool card href:

```html
<!-- Compress PDF card -->
<a href="/compress-pdf">...</a>

<!-- Merge PDF card -->  
<a href="/merge-pdf">...</a>

<!-- Split PDF card -->
<a href="/split-pdf">...</a>

<!-- Word to PDF card -->
<a href="/word-to-pdf">...</a>
```

---

## STEP 6 — Submit pages to Google Search Console

After uploading:
1. Go to https://search.google.com/search-console
2. Add your property (allpdfstuff.com) if not already added
3. Go to URL Inspection → paste each new page URL
4. Click "Request Indexing" for each one

Do this for:
- https://www.allpdfstuff.com/compress-pdf
- https://www.allpdfstuff.com/merge-pdf
- https://www.allpdfstuff.com/split-pdf
- https://www.allpdfstuff.com/pdf-to-word
- https://www.allpdfstuff.com/word-to-pdf

---

## WHAT EACH PAGE TARGETS (SEO keywords)

| Page | Primary keyword | Secondary keywords |
|------|----------------|-------------------|
| compress-pdf | compress PDF online | reduce PDF size, compress PDF for email, compress PDF under 1MB |
| merge-pdf | merge PDF online free | combine PDF files, join PDFs |
| split-pdf | split PDF online | extract pages from PDF, split PDF by page range |
| pdf-to-word | PDF to Word converter | convert PDF to DOCX, editable PDF |
| word-to-pdf | Word to PDF converter | convert DOCX to PDF, doc to PDF |

---

## EXPECTED TIMELINE

- Week 1–2: Google crawls and indexes the new pages
- Week 2–4: Early impressions for long-tail keywords
- Month 2–3: Consistent traffic from tool-specific searches

---

## NEXT STEPS (when you're ready)

1. **Blog posts** — Write 2–3 articles targeting problem-based keywords:
   - "How to compress a PDF without losing quality"
   - "How to reduce PDF file size for email"
   - "Best way to merge PDF files on Mac or Windows"
   Each article should link back to the relevant tool page.

2. **Long-tail pages** — Create additional pages for:
   - /compress-pdf-under-1mb
   - /compress-pdf-for-email

3. **Backlinks** — Submit to directories:
   - Product Hunt (launch your tool)
   - AlternativeTo.net
   - Publish a short post on Medium or Dev.to linking to your tools

---

*Generated for allpdfstuff.com — © 2026*
